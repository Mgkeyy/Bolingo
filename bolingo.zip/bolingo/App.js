import React, { useState, useEffect } from 'react';
import { 
  View, Text, StyleSheet, TouchableOpacity, Animated, 
  PanResponder, Dimensions, TextInput, Image, FlatList,
  Modal, ScrollView, Alert
} from 'react-native';

const { width, height } = Dimensions.get('window');

// =========== ÉCRAN DE CHAT ===========
const ChatScreen = ({ match, onRetour }) => {
  const [messages, setMessages] = useState([
    { id: 1, texte: 'Salut ! 👋', envoyeur: match.prenom, temps: '10:30' },
    { id: 2, texte: 'Comment ça va ?', envoyeur: match.prenom, temps: '10:31' },
    { id: 3, texte: 'Ça va super ! Et toi ?', envoyeur: 'moi', temps: '10:32' },
  ]);
  const [nouveauMessage, setNouveauMessage] = useState('');

  const envoyerMessage = () => {
    if (nouveauMessage.trim()) {
      const nouveau = {
        id: messages.length + 1,
        texte: nouveauMessage,
        envoyeur: 'moi',
        temps: new Date().getHours() + ':' + new Date().getMinutes()
      };
      setMessages([...messages, nouveau]);
      setNouveauMessage('');
    }
  };

  return (
    <View style={styles.chatContainer}>
      {/* En-tête du chat */}
      <View style={styles.chatHeader}>
        <TouchableOpacity onPress={onRetour} style={styles.retourButton}>
          <Text style={styles.retourTexte}>← Retour</Text>
        </TouchableOpacity>
        <View style={styles.chatHeaderInfo}>
          <View style={[styles.chatAvatar, { backgroundColor: '#ffcccc' }]}>
            <Text style={styles.chatAvatarTexte}>{match.emoji}</Text>
          </View>
          <Text style={styles.chatHeaderNom}>{match.prenom}, {match.age}</Text>
        </View>
      </View>

      {/* Messages */}
      <FlatList
        data={messages}
        keyExtractor={(item) => item.id.toString()}
        style={styles.messagesList}
        renderItem={({ item }) => (
          <View style={[
            styles.messageBulle,
            item.envoyeur === 'moi' ? styles.messageMoi : styles.messageAutre
          ]}>
            <Text style={styles.messageTexte}>{item.texte}</Text>
            <Text style={styles.messageTemps}>{item.temps}</Text>
          </View>
        )}
      />

      {/* Zone de saisie */}
      <View style={styles.chatInputContainer}>
        <TextInput
          style={styles.chatInput}
          value={nouveauMessage}
          onChangeText={setNouveauMessage}
          placeholder="Écris ton message..."
          placeholderTextColor="#999"
        />
        <TouchableOpacity style={styles.chatEnvoyer} onPress={envoyerMessage}>
          <Text style={styles.chatEnvoyerTexte}>Envoyer</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

// =========== ÉCRAN PRINCIPAL ===========
export default function App() {
  const [prenom, setPrenom] = useState('');
  const [nom, setNom] = useState(''); // ✅ NOUVEAU : champ pour le nom
  const [age, setAge] = useState('');
  const [bio, setBio] = useState('');
  const [etape, setEtape] = useState(1);
  const [mode, setMode] = useState('swipe'); // 'swipe' ou 'chat'
  const [matchActuel, setMatchActuel] = useState(null);
  
  // Nos profils avec VRAIES photos
  const [profils, setProfils] = useState([
    { 
      id: 1, 
      prenom: 'Sophie', 
      nom: 'Martin',
      age: 25, 
      bio: 'J\'adore les voyages et le café ☕\nParisienne, je cherche quelqu\'un pour explorer le monde !',
      emoji: '✈️',
      image: 'https://images.unsplash.com/photo-1494790108777-383fd5c3a5f7?w=400',
      distance: '5 km',
      interets: ['Voyage', 'Café', 'Photo']
    },
    { 
      id: 2, 
      prenom: 'Thomas', 
      nom: 'Dubois',
      age: 28, 
      bio: 'Musicien, fan de rock et de montagne 🎸\nGuitariste dans un groupe, je cherche l\'âme sœur pour des duos !',
      emoji: '⛰️',
      image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400',
      distance: '12 km',
      interets: ['Musique', 'Montagne', 'Rock']
    },
    { 
      id: 3, 
      prenom: 'Emma', 
      nom: 'Petit',
      age: 23, 
      bio: 'Photographe, cherche âme sœur pour aventures 📸\nLa vie est un spectacle, je veux le partager avec toi.',
      emoji: '📷',
      image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400',
      distance: '3 km',
      interets: ['Photo', 'Art', 'Nature']
    },
    { 
      id: 4, 
      prenom: 'Lucas', 
      nom: 'Bernard',
      age: 30, 
      bio: 'Sportif, passionné de cuisine 🏋️‍♂️\nJe cherche quelqu\'un pour faire du sport et bien manger !',
      emoji: '🍳',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400',
      distance: '8 km',
      interets: ['Sport', 'Cuisine', 'Fitness']
    },
    { 
      id: 5, 
      prenom: 'Léa', 
      nom: 'Robert',
      age: 26, 
      bio: 'Libraire, amoureuse des livres et des chats 📚\nUn bon livre, un chat, et toi ? Le paradis !',
      emoji: '🐱',
      image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400',
      distance: '15 km',
      interets: ['Lecture', 'Chats', 'Écriture']
    },
    { 
      id: 6, 
      prenom: 'Mohamed', 
      nom: 'Benali',
      age: 29, 
      bio: 'Chef cuisinier, cherche goûteuse pour mes plats 👨‍🍳\nLa cuisine est mon langage, l\'amour mon ingrédient secret.',
      emoji: '🍲',
      image: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=400',
      distance: '2 km',
      interets: ['Cuisine', 'Voyage', 'Gastronomie']
    },
    { 
      id: 7, 
      prenom: 'Claire', 
      nom: 'Leroy',
      age: 27, 
      bio: 'Infirmière, le cœur sur la main 👩‍⚕️\nJe prends soin des autres, j\'aimerais quelqu\'un qui prenne soin de moi.',
      emoji: '❤️',
      image: 'https://images.unsplash.com/photo-1554151228-14d9def656e4?w=400',
      distance: '6 km',
      interets: ['Médecine', 'Sport', 'Bénévolat']
    },
  ]);
  
  const [indexProfil, setIndexProfil] = useState(0);
  const [matchs, setMatchs] = useState([]);
  const [showProfilModal, setShowProfilModal] = useState(false);

  // Animation de swipe
  const position = new Animated.ValueXY();
  
  const panResponder = PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onPanResponderMove: (evt, gesture) => {
      position.setValue({ x: gesture.dx, y: 0 });
    },
    onPanResponderRelease: (evt, gesture) => {
      if (gesture.dx > 120) {
        swipeDroite();
      } else if (gesture.dx < -120) {
        swipeGauche();
      } else {
        Animated.spring(position, {
          toValue: { x: 0, y: 0 },
          useNativeDriver: false,
        }).start();
      }
    },
  });

  const swipeDroite = () => {
    Animated.timing(position, {
      toValue: { x: width + 100, y: 0 },
      duration: 250,
      useNativeDriver: false,
    }).start(() => {
      // Match (70% de chance pour plus de fun)
      if (Math.random() > 0.3) {
        const nouveauMatch = profils[indexProfil];
        setMatchs([...matchs, nouveauMatch]);
        Alert.alert(
          '💕 C\'est un MATCH !',
          `Toi et ${nouveauMatch.prenom} vous êtes likés !`,
          [{ text: 'Continuer à swiper' }]
        );
      }
      passerProfilSuivant();
    });
  };

  const swipeGauche = () => {
    Animated.timing(position, {
      toValue: { x: -width - 100, y: 0 },
      duration: 250,
      useNativeDriver: false,
    }).start(() => {
      passerProfilSuivant();
    });
  };

  const passerProfilSuivant = () => {
    if (indexProfil < profils.length - 1) {
      setIndexProfil(indexProfil + 1);
      position.setValue({ x: 0, y: 0 });
    } else {
      setEtape(4); // Plus de profils
    }
  };

  const rotation = position.x.interpolate({
    inputRange: [-width, 0, width],
    outputRange: ['-10deg', '0deg', '10deg'],
  });

  const likeOpacity = position.x.interpolate({
    inputRange: [0, 100],
    outputRange: [0, 1],
  });

  const nopeOpacity = position.x.interpolate({
    inputRange: [-100, 0],
    outputRange: [1, 0],
  });

  // Si on est dans le chat
  if (mode === 'chat' && matchActuel) {
    return <ChatScreen match={matchActuel} onRetour={() => setMode('matchs')} />;
  }

  // Écran des matchs (entre swipe et chat)
  if (mode === 'matchs') {
    return (
      <View style={styles.container}>
        <Text style={styles.header}>Mes Matchs ❤️</Text>
        <Text style={styles.matchsSousTitre}>
          {matchs.length} match{matchs.length > 1 ? 's' : ''}
        </Text>
        
        <FlatList
          data={matchs}
          keyExtractor={(item) => item.id.toString()}
          style={styles.matchsListe}
          renderItem={({ item }) => (
            <TouchableOpacity 
              style={styles.matchItem}
              onPress={() => {
                setMatchActuel(item);
                setMode('chat');
              }}
            >
              <Image source={{ uri: item.image }} style={styles.matchAvatar} />
              <View style={styles.matchInfo}>
                <Text style={styles.matchNom}>{item.prenom} {item.nom}, {item.age}</Text>
                <Text style={styles.matchDistance}>{item.distance}</Text>
              </View>
              <Text style={styles.matchChat}>💬</Text>
            </TouchableOpacity>
          )}
        />
        
        <TouchableOpacity 
          style={styles.boutonSecondaire}
          onPress={() => setMode('swipe')}
        >
          <Text style={styles.boutonSecondaireTexte}>Continuer à swiper</Text>
        </TouchableOpacity>
      </View>
    );
  }

  // Écran d'inscription - MODIFIÉ AVEC LE CHAMP NOM
  if (etape === 1) {
    return (
      <View style={styles.container}>
        <Text style={styles.grandTitre}>Bolingo ❤️</Text>
        <Text style={styles.sousTitre}>L'amour commence ici</Text>
        
        <TextInput
          style={styles.input}
          placeholder="Ton prénom"
          placeholderTextColor="#999"
          value={prenom}
          onChangeText={setPrenom}
        />
        
        {/* ✅ NOUVEAU : Champ pour le nom */}
        <TextInput
          style={styles.input}
          placeholder="Ton nom"
          placeholderTextColor="#999"
          value={nom}
          onChangeText={setNom}
        />
        
        <TextInput
          style={styles.input}
          placeholder="Ton âge"
          placeholderTextColor="#999"
          keyboardType="numeric"
          value={age}
          onChangeText={setAge}
        />
        
        <TextInput
          style={[styles.input, styles.textArea]}
          placeholder="Parle-nous de toi (bio)"
          placeholderTextColor="#999"
          multiline
          numberOfLines={3}
          value={bio}
          onChangeText={setBio}
        />
        
        <TouchableOpacity 
          style={styles.bouton} 
          onPress={() => setEtape(2)}
        >
          <Text style={styles.boutonTexte}>Créer mon profil</Text>
        </TouchableOpacity>
      </View>
    );
  }

  // Écran d'accueil après inscription - MODIFIÉ POUR AFFICHER PRÉNOM + NOM
  if (etape === 2) {
    return (
      <View style={styles.container}>
        <Text style={styles.grandTitre}>Bolingo ❤️</Text>
        <View style={styles.profilePreview}>
          <View style={styles.avatarPlaceholder}>
            <Text style={styles.avatarEmoji}>📸</Text>
          </View>
          <Text style={styles.profilePreviewNom}>{prenom} {nom}, {age} ans</Text>
          <Text style={styles.profilePreviewBio}>{bio || "Ta bio apparaîtra ici"}</Text>
        </View>
        
        <TouchableOpacity 
          style={styles.bouton} 
          onPress={() => setEtape(3)}
        >
          <Text style={styles.boutonTexte}>Commencer les rencontres</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.matchsButton}
          onPress={() => setMode('matchs')}
        >
          <Text style={styles.matchsButtonTexte}>Voir mes matchs ({matchs.length})</Text>
        </TouchableOpacity>
      </View>
    );
  }

  // Écran de swipe
  if (etape === 3) {
    const profil = profils[indexProfil];
    
    if (!profil) return null;

    return (
      <View style={styles.container}>
        <View style={styles.topBar}>
          <Text style={styles.header}>Bolingo ❤️</Text>
          <TouchableOpacity 
            style={styles.matchsBadge}
            onPress={() => setMode('matchs')}
          >
            <Text style={styles.matchsBadgeTexte}>Matchs: {matchs.length}</Text>
          </TouchableOpacity>
        </View>
        
        <Animated.View
          {...panResponder.panHandlers}
          style={[
            styles.carte,
            {
              transform: [
                { translateX: position.x },
                { rotate: rotation },
              ],
            },
          ]}
        >
          <Animated.View style={[styles.likeLabel, { opacity: likeOpacity }]}>
            <Text style={styles.likeText}>❤️ LIKE</Text>
          </Animated.View>
          
          <Animated.View style={[styles.nopeLabel, { opacity: nopeOpacity }]}>
            <Text style={styles.nopeText}>✗ NOPE</Text>
          </Animated.View>
          
          <Image 
            source={{ uri: profil.image }} 
            style={styles.carteImage}
          />
          
          <View style={styles.carteInfo}>
            <View style={styles.carteHeader}>
              <Text style={styles.cartePrenom}>{profil.prenom} {profil.nom}, {profil.age}</Text>
              <Text style={styles.carteDistance}>{profil.distance}</Text>
            </View>
            
            <Text style={styles.carteBio}>{profil.bio}</Text>
            
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.interetsContainer}>
              {profil.interets.map((interet, idx) => (
                <View key={idx} style={styles.interetBadge}>
                  <Text style={styles.interetTexte}>{interet}</Text>
                </View>
              ))}
            </ScrollView>
          </View>
        </Animated.View>
        
        <View style={styles.boutonsCarte}>
          <TouchableOpacity style={styles.boutonNon} onPress={swipeGauche}>
            <Text style={styles.boutonNonTexte}>✗</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.boutonSuper} onPress={() => {
            Alert.alert('Super Like !', 'Tu as 3x plus de chances de matcher !');
            swipeDroite();
          }}>
            <Text style={styles.boutonSuperTexte}>⭐</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.boutonOui} onPress={swipeDroite}>
            <Text style={styles.boutonOuiTexte}>❤️</Text>
          </TouchableOpacity>
        </View>
        
        <Text style={styles.compteur}>{indexProfil + 1} / {profils.length}</Text>
      </View>
    );
  }

  // Écran plus de profils
  if (etape === 4) {
    return (
      <View style={styles.container}>
        <Text style={styles.grandTitre}>Bolingo ❤️</Text>
        <View style={styles.finishIcon}>
          <Text style={styles.finishEmoji}>✨</Text>
        </View>
        <Text style={styles.messageBienvenue}>
          Plus de profils pour aujourd'hui !
        </Text>
        <Text style={styles.sousMessage}>
          Tu as matché avec {matchs.length} personne{matchs.length > 1 ? 's' : ''}
        </Text>
        
        {matchs.length > 0 ? (
          <TouchableOpacity 
            style={styles.bouton}
            onPress={() => setMode('matchs')}
          >
            <Text style={styles.boutonTexte}>Voir mes matchs</Text>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity 
            style={styles.bouton}
            onPress={() => {
              setIndexProfil(0);
              setEtape(3);
            }}
          >
            <Text style={styles.boutonTexte}>Recommencer</Text>
          </TouchableOpacity>
        )}
      </View>
    );
  }
}

// =========== STYLES ===========
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff0f0',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  topBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: '100%',
    position: 'absolute',
    top: 50,
    paddingHorizontal: 20,
  },
  header: {
    fontSize: 24,
    color: '#ff4d4d',
    fontWeight: 'bold',
  },
  grandTitre: {
    fontSize: 48,
    color: '#ff4d4d',
    fontWeight: 'bold',
    marginBottom: 10,
  },
  sousTitre: {
    fontSize: 20,
    color: '#666',
    marginBottom: 40,
  },
  profilePreview: {
    backgroundColor: 'white',
    width: '100%',
    borderRadius: 20,
    padding: 20,
    alignItems: 'center',
    marginBottom: 30,
  },
  avatarPlaceholder: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#ffcccc',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 15,
  },
  avatarEmoji: {
    fontSize: 40,
  },
  profilePreviewNom: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#ff4d4d',
    marginBottom: 5,
  },
  profilePreviewBio: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
  },
  matchsButton: {
    marginTop: 20,
    padding: 10,
  },
  matchsButtonTexte: {
    color: '#ff4d4d',
    fontSize: 18,
    fontWeight: 'bold',
  },
  matchsBadge: {
    backgroundColor: '#ff4d4d',
    paddingHorizontal: 15,
    paddingVertical: 5,
    borderRadius: 20,
  },
  matchsBadgeTexte: {
    color: 'white',
    fontWeight: 'bold',
  },
  input: {
    width: '100%',
    height: 50,
    borderWidth: 2,
    borderColor: '#ffcccc',
    borderRadius: 25,
    paddingHorizontal: 20,
    fontSize: 18,
    marginBottom: 15,
    backgroundColor: 'white',
  },
  textArea: {
    height: 100,
    textAlignVertical: 'top',
    paddingTop: 15,
  },
  bouton: {
    backgroundColor: '#ff4d4d',
    paddingHorizontal: 40,
    paddingVertical: 15,
    borderRadius: 25,
    marginTop: 20,
    width: '100%',
    alignItems: 'center',
  },
  boutonTexte: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  boutonSecondaire: {
    backgroundColor: 'white',
    paddingHorizontal: 40,
    paddingVertical: 15,
    borderRadius: 25,
    marginTop: 10,
    width: '100%',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#ff4d4d',
  },
  boutonSecondaireTexte: {
    color: '#ff4d4d',
    fontSize: 18,
    fontWeight: 'bold',
  },
  carte: {
    backgroundColor: 'white',
    width: '100%',
    borderRadius: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
    marginTop: 100,
    marginBottom: 20,
  },
  carteImage: {
    width: '100%',
    height: 300,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  },
  carteInfo: {
    padding: 20,
  },
  carteHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  cartePrenom: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#ff4d4d',
  },
  carteDistance: {
    fontSize: 16,
    color: '#666',
    backgroundColor: '#f0f0f0',
    paddingHorizontal: 10,
    paddingVertical: 3,
    borderRadius: 12,
  },
  carteBio: {
    fontSize: 16,
    color: '#666',
    marginBottom: 15,
    lineHeight: 22,
  },
  interetsContainer: {
    flexDirection: 'row',
    marginBottom: 10,
  },
  interetBadge: {
    backgroundColor: '#ff4d4d20',
    paddingHorizontal: 15,
    paddingVertical: 5,
    borderRadius: 15,
    marginRight: 10,
    borderWidth: 1,
    borderColor: '#ff4d4d40',
  },
  interetTexte: {
    color: '#ff4d4d',
    fontSize: 14,
  },
  likeLabel: {
    position: 'absolute',
    top: 40,
    left: 30,
    transform: [{ rotate: '-15deg' }],
    borderWidth: 3,
    borderColor: '#4CAF50',
    padding: 8,
    borderRadius: 10,
    zIndex: 100,
    backgroundColor: 'rgba(255,255,255,0.9)',
  },
  likeText: {
    color: '#4CAF50',
    fontSize: 24,
    fontWeight: 'bold',
  },
  nopeLabel: {
    position: 'absolute',
    top: 40,
    right: 30,
    transform: [{ rotate: '15deg' }],
    borderWidth: 3,
    borderColor: '#ff4d4d',
    padding: 8,
    borderRadius: 10,
    zIndex: 100,
    backgroundColor: 'rgba(255,255,255,0.9)',
  },
  nopeText: {
    color: '#ff4d4d',
    fontSize: 24,
    fontWeight: 'bold',
  },
  boutonsCarte: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    width: '100%',
    marginTop: 10,
  },
  boutonNon: {
    backgroundColor: '#f0f0f0',
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  boutonNonTexte: {
    fontSize: 30,
    color: '#999',
  },
  boutonSuper: {
    backgroundColor: '#4CAF50',
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
  },
  boutonSuperTexte: {
    fontSize: 25,
    color: 'white',
  },
  boutonOui: {
    backgroundColor: '#ff4d4d',
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  boutonOuiTexte: {
    fontSize: 30,
    color: 'white',
  },
  compteur: {
    marginTop: 10,
    color: '#666',
    fontSize: 14,
  },
  finishIcon: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#ffcccc',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  finishEmoji: {
    fontSize: 50,
  },
  messageBienvenue: {
    fontSize: 24,
    color: '#ff4d4d',
    fontWeight: 'bold',
    marginBottom: 10,
    textAlign: 'center',
  },
  sousMessage: {
    fontSize: 18,
    color: '#666',
    marginBottom: 40,
  },
  // Styles pour les matchs
  matchsListe: {
    width: '100%',
    marginTop: 20,
    marginBottom: 20,
  },
  matchItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 15,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  matchAvatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    marginRight: 15,
  },
  matchInfo: {
    flex: 1,
  },
  matchNom: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ff4d4d',
  },
  matchDistance: {
    fontSize: 14,
    color: '#666',
  },
  matchChat: {
    fontSize: 24,
  },
  matchsSousTitre: {
    fontSize: 16,
    color: '#666',
    marginTop: 70,
  },
  // Styles pour le chat
  chatContainer: {
    flex: 1,
    backgroundColor: '#fff0f0',
  },
  chatHeader: {
    backgroundColor: '#ff4d4d',
    paddingTop: 50,
    paddingBottom: 20,
    paddingHorizontal: 20,
    flexDirection: 'row',
    alignItems: 'center',
  },
  retourButton: {
    marginRight: 15,
  },
  retourTexte: {
    color: 'white',
    fontSize: 16,
  },
  chatHeaderInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  chatAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  chatAvatarTexte: {
    fontSize: 20,
  },
  chatHeaderNom: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  messagesList: {
    flex: 1,
    padding: 20,
  },
  messageBulle: {
    maxWidth: '80%',
    padding: 12,
    borderRadius: 20,
    marginBottom: 10,
  },
  messageMoi: {
    backgroundColor: '#ff4d4d',
    alignSelf: 'flex-end',
    borderBottomRightRadius: 5,
  },
  messageAutre: {
    backgroundColor: 'white',
    alignSelf: 'flex-start',
    borderBottomLeftRadius: 5,
  },
  messageTexte: {
    fontSize: 16,
    color: '#333',
  },
  messageTemps: {
    fontSize: 10,
    color: '#999',
    alignSelf: 'flex-end',
    marginTop: 5,
  },
  chatInputContainer: {
    flexDirection: 'row',
    padding: 10,
    backgroundColor: 'white',
    borderTopWidth: 1,
    borderTopColor: '#ffcccc',
  },
  chatInput: {
    flex: 1,
    height: 40,
    borderWidth: 1,
    borderColor: '#ffcccc',
    borderRadius: 20,
    paddingHorizontal: 15,
    marginRight: 10,
    backgroundColor: '#fff9f9',
  },
  chatEnvoyer: {
    backgroundColor: '#ff4d4d',
    paddingHorizontal: 20,
    borderRadius: 20,
    justifyContent: 'center',
  },
  chatEnvoyerTexte: {
    color: 'white',
    fontWeight: 'bold',
  },
});